n1.all_stocks.values.each do |seed|
#     seed.plant(7)
# end


# #to record the new information in a new file after planting 7 grams of each type
# n1.newrecord("newdata.tsv")